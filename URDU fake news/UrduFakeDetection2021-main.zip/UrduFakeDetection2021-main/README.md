# UrduFakeDetection2021
Code for The 2021 Urdu Fake News Detection Task
